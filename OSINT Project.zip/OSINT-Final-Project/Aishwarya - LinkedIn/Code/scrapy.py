import csv
from parsel import Selector
from time import sleep
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

writer = csv.writer(open('output.csv', 'w+', encoding='utf-8-sig', newline=''))
writer.writerow(['Name', 'Position', 'Company', 'Education', 'Location', 'URL'])
ana = ['developer', 'Machine Learning', 'Analyst', 'AEM Developer', 'Networking', 'UI', 'Manager', 'Tester', 'Director', 'CTO']
#ana = ['Bangalore', 'Chicago', 'New York', 'California', 'Delhi', 'China', 'Hyderabad']
driver = webdriver.Chrome(
    '/Users/aishwaryajavagalsatyanarayan/Downloads/chromedriver')  # Install chrome driver for your current chrome version
driver.get('https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin')

username = driver.find_element_by_name("session_key")
username.send_keys('')  # Write ur E-mail Id
sleep(2.0)

password = driver.find_element_by_name('session_password')
password.send_keys('')  # Put Ur LinkedIn Password
sleep(2.0)

sign_in_button = driver.find_element_by_class_name('login__form_action_container')
sign_in_button.click()
sleep(1.0)
# for a in ana:
for a in ana:
    print(a)
    driver.get('https://www.google.com/')
    search_query = driver.find_element_by_name('q')
    search_query.send_keys('site:linkedin.com/in AND ', a)
    search_query.send_keys(Keys.RETURN)
    sleep(1.0)

    urls = driver.find_elements_by_xpath('//*[@class = "r"]/a[@href]')
    urls = [url.get_attribute('href') for url in urls]
    print(urls)
    sleep(1.0)

    for url in urls:
        driver.get(url)
        sleep(1.0)

        sel = Selector(text=driver.page_source)

        name = sel.xpath('//*[@class = "inline t-24 t-black t-normal break-words"]/text()').extract_first()
        name = ''.join(name) if name else None

        position = sel.xpath('//*[@class = "mt1 t-18 t-black t-normal"]/text()').extract_first()
        position = ''.join(position)  if position else None
        sleep(1.0)
        experience = sel.xpath('//*[@class = "pv-entity__secondary-title t-14 t-black t-normal"]/text()')
        company = experience.extract_first()
        company = ''.join(company.split()) if company else None
        education = sel.xpath('//*[@class = "pv-entity__school-name t-16 t-black t-bold"]/text()').extract_first()
        print("education ", education)
        education = ''.join(education.split()) if education else None
        location = sel.xpath('//*[@class = "t-16 t-black t-normal inline-block"]/text()').extract_first()
        location = ''.join(location.split()) if location else None

        url = driver.current_url

        print('\n')
        print('Name: ', name)
        print('Position: ', position)
        print('Company: ', company)
        print('Education: ', education)
        print('Location: ', location)
        print('URL: ', url)
        print('\n')

        writer.writerow([name,
                         position,
                         company,
                         education,
                         location,
                         url])

driver.quit()
