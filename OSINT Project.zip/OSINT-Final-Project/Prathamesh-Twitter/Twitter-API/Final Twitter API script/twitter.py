import tweepy
import sys
import csv
from tweepy.api import API
import twitter
from TwitterAPI import TwitterAPI
from tkinter import *
from PIL import Image
from PIL import ImageTk

consumer_key = "HNi58vvldQzlmutsfwYothhBV"
consumer_secret = "zwwuqLzBaZAeJPySNsfK3LLrV6bCI2KXCjsGdsIoAqupQ6fP49"
access_token = "144774294-bOXohbyI0MYekNvTxIcEzhjIi4ZMX434PXIYrPMY"
access_token_secret = "Ka5tPC99bJUzXcZ3UDs5WW0nobxW21SgdYGJcAO7G3lB2"



def tweetActionMethod():
	print("Inside searchQuery")
	name = e1.get()
	search = e2.get()
	language = "en"
	# Number of tweets to pull
	tweetCount = 100
	
	file = open('result.csv',"x")
	# Calling the user timeline function with our paraneters
	results = api.user_timeline(id=name, count=tweetCount)
	Searchresults = api.search(q=search, lang=language)
	# for each through all tweets Pulled
	csvFile = csv.writer(file)
	csvFile.writerow(["Created At", "Username", "Text"])

	for tweet in results:
		print(tweet.created_at, tweet.user.screen_name, tweet.text)
		csvFile.writerow([tweet.created_at, tweet.user.screen_name, tweet.text])     
	for tweet in Searchresults:
		print(tweet.created_at, tweet.user.screen_name, tweet.text)
		csvFile.writerow([tweet.created_at, tweet.user.screen_name, tweet.text])
	file.close()

def get_all_tweets(screen_name):
	#Twitter only allows access to a users most recent 3240 tweets with this method
	
	#authorize twitter, initialize tweepy
	#auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
	#auth.set_access_token(access_token, access_token_secret)
	#api = tweepy.API(auth)
	
	#initialize a list to hold all the tweepy Tweets
	alltweets = []	
	
	#make initial request for most recent tweets (200 is the maximum allowed count)
	new_tweets = api.user_timeline(screen_name = screen_name,count=200)
	
	#save most recent tweets
	alltweets.extend(new_tweets)
	
	#save the id of the oldest tweet less one
	oldest = alltweets[-1].id - 1
	
	#keep grabbing tweets until there are no tweets left to grab
	while len(new_tweets) > 0:
		print ("getting tweets before %s" % (oldest))
		
		#all subsiquent requests use the max_id param to prevent duplicates
		new_tweets = api.user_timeline(screen_name = screen_name,count=200,max_id=oldest)
		
		#save most recent tweets
		alltweets.extend(new_tweets)
		
		#update the id of the oldest tweet less one
		oldest = alltweets[-1].id - 1
		
		print ("...%s tweets downloaded so far" % (len(alltweets)))
	
	#transform the tweepy tweets into a 2D array that will populate the csv	
	outtweets = [[tweet.id_str, tweet.created_at, tweet.text.encode("utf-8")] for tweet in alltweets]
	
	#write the csv	
	with open('%s_tweets.csv' % screen_name, 'w') as f:
		writer = csv.writer(f)
		writer.writerow(["id","created_at","text"])
		writer.writerows(outtweets)
	
	pass

def search_for_hashtags(consumer_key, consumer_secret, access_token, access_token_secret, hashtag_phrase):
    
    #create authentication for accessing Twitter
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)

    #initialize Tweepy API
    api = tweepy.API(auth)
    
    #get the name of the spreadsheet we will write to
    fname = '_'.join(re.findall(r"#(\w+)", hashtag_phrase))

    #open the spreadsheet we will write to
    with open('%s.csv' % (fname), 'w') as file:

        w = csv.writer(file)

        #write header row to spreadsheet
        w.writerow(['timestamp', 'tweet_text', 'username', 'all_hashtags', 'followers_count'])

        #for each tweet matching our hashtags, write relevant info to the spreadsheet
        for tweet in tweepy.Cursor(api.search, q=hashtag_phrase+' -filter:retweets', \
                                   lang="en", tweet_mode='extended').items(100):
            w.writerow([tweet.created_at, tweet.full_text.replace('\n',' ').encode('utf-8'), tweet.user.screen_name.encode('utf-8'), [e['text'] for e in tweet._json['entities']['hashtags']], tweet.user.followers_count])



if __name__ == '__main__':
	auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
	auth.set_access_token(access_token, access_token_secret)
	api = tweepy.API(auth)
	#window = Tk()
	#window.title('Twitter')
	#window.geometry('400x400')
	#window.configure(background="cyan2")
	#image = Image.open("twitter_general.jpg")
	#image = image.resize((150, 150),Image.ANTIALIAS)
	#image.save("twit.jpg")
	#pic = ImageTk.PhotoImage(file="twit.jpg")
	#photo = Label(window, anchor=NW, image=pic)
	#label1 = Label(window, text='Enter Name', width=20)
	#label2 = Label(window, text='Enter keyword to search', width=20)
	#e1 = Entry(window, width=30)
	#e2 = Entry(window, width=30)
	#photo.pack(pady=5)
	#label1.pack(pady=5)
	#e1.pack()
	#label2.pack(pady=5)
	#e2.pack()
	#button = Button(window, text='Get Data', command=tweetActionMethod, width=25)
	#button.pack(pady=20)
	#colors = [label1, label2, e1, e2, button, photo]
	#for x in colors:
#		x.configure(bg="cyan2")
	#window.mainloop()
	#tweetActionMethod()
	#get_all_tweets("kalilinux")
	consumer_key = input('Consumer Key ')
	consumer_secret = input('Consumer Secret ')
	access_token = input('Access Token ')
	access_token_secret = input('Access Token Secret ')
	hashtag_phrase = input('Hashtag Phrase ')
	search_for_hashtags(consumer_key, consumer_secret, access_token, access_token_secret, hashtag_phrase)

	
