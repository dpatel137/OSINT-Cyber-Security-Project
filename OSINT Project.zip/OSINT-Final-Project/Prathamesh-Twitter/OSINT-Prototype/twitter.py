import tweepy
import sys
import csv
from tweepy.api import API
import twitter
from TwitterAPI import TwitterAPI
from tkinter import *
from PIL import Image
from PIL import ImageTk

consumer_key = "QA2zh5NJ0nfBRu7qWmQJUGr3D"
consumer_secret = "bS8K7YS9FmNWt25Q8IqIYcThAOucM7lWrR9vTpUjiI3g3ajvCT"
access_token = "144774294-7Mpe1V8Cmo5B3mCPCpnR8VowpGopOBYigXZ5KRFs"
access_token_secret = "m3tKhj1oprP6wOTwhCkiujUldEN2MDHxIH2v5JIJdgI5d"



def tweetActionMethod():
	print("Inside searchQuery")
	name = e1.get()
	search = e2.get()
	language = "en"
	# Number of tweets to pull
	tweetCount = 100
	
	file = open('result.csv',"x")
	# Calling the user timeline function with our paraneters
	results = api.user_timeline(id=name, count=tweetCount)
	Searchresults = api.search(q=search, lang=language)
	# for each through all tweets Pulled
	csvFile = csv.writer(file)
	csvFile.writerow(["Created At", "Username", "Text"])

	for tweet in results:
		print(tweet.created_at, tweet.user.screen_name, tweet.text)
		csvFile.writerow([tweet.created_at, tweet.user.screen_name, tweet.text])     
	for tweet in Searchresults:
		print(tweet.created_at, tweet.user.screen_name, tweet.text)
		csvFile.writerow([tweet.created_at, tweet.user.screen_name, tweet.text])
	file.close()



if __name__ == '__main__':
	auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
	auth.set_access_token(access_token, access_token_secret)
	api = tweepy.API(auth)
	window = Tk()
	window.title('Twitter')
	window.geometry('400x400')
	window.configure(background="cyan2")
	image = Image.open("twitter_general.jpg")
	image = image.resize((150, 150),Image.ANTIALIAS)
	image.save("twit.jpg")
	pic = ImageTk.PhotoImage(file="twit.jpg")
	photo = Label(window, anchor=NW, image=pic)
	label1 = Label(window, text='Enter Name', width=20)
	label2 = Label(window, text='Enter keyword to search', width=20)
	e1 = Entry(window, width=30)
	e2 = Entry(window, width=30)
	photo.pack(pady=5)
	label1.pack(pady=5)
	e1.pack()
	label2.pack(pady=5)
	e2.pack()
	button = Button(window, text='Get Data', command=tweetActionMethod, width=25)
	button.pack(pady=20)
	colors = [label1, label2, e1, e2, button, photo]
	for x in colors:
		x.configure(bg="cyan2")
	window.mainloop()
	tweetActionMethod()
	
