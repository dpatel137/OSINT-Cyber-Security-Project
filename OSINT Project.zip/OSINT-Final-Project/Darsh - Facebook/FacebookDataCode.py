
import facebook
import pandas

token = "EAAHv06MQWM0BAOMOAXnZBW8dsJx7Eh4SHDQ5x8n2OyB752OwvMqbfZCSZBEGbQk7f2z4OH3WslvfIBuI5hrrJtiZBEZBrtyhqdvyyKqNZCcxLnhyO14hypzo9ZAiGPV2FgsZAETRFN4RsZCMZBMib9YhanPtPD9tGQjJIjzyFjiIhYlvC8kJOwjKN9bLV8Af3aeB9MHo0vqaOCRf4ARXqUB8Wxk72BLAb2lWYZD"

graph = facebook.GraphAPI(access_token=token, version = 2.12)
events = graph.request('me?fields=posts{created_time,actions,instagram_eligibility,message_tags,place}') 
print(events)
pandas.DataFrame(events)
eventList = events['posts']
pandas.DataFrame.from_dict(eventList["data"]).to_csv("check.csv")